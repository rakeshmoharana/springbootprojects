package com.movies.moviecatalogueservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatalogueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
